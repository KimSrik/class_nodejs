const express = require('express');
const app = express();

// body-parser
app.use(express.urlencoded({extended:true}));
app.use(express.json());

// mongoDB
const MongoClient = require('mongodb').MongoClient;

// EJS
app.set('view engine', 'ejs');
// 앱에 전처리 번역기로 ejs를 사용하겠다.

// DB Access
let todoAppDBURL = 'mongodb+srv://admin:qwer1234@cluster0.mikzh.mongodb.net/todoAppDB?retryWrites=true&w=majority';
let todoAppDB;

// MongoClient.connect('url', callback);
MongoClient.connect(todoAppDBURL, (err,result)=>{
  if(err) return console.log(err);
  
  todoAppDB = result.db('todoAppDB');
  // todoAppDB.collection('todoApp').insertOne({title: '수업듣기', order: 2}, function(err, result){
  //   if(err) return console.log(err);
  //   console.log('저장성공');
  // });

  // server open
  app.listen(8080,()=>{
    console.log('8080포트가 열렸습니다.');
  });
});




// '/'로 접속시 시작페이지를 보내주자
// app.get('/', (req, res)=>{
//   res.sendFile(__dirname + '/index.html');
//   console.log('index.html 응답완료');
// });

// '/write'로 접속시 write.html를 보내주자
app.get('/write', (req, res)=>{
  res.sendFile(__dirname + '/write.html');
});
// '/delete'로 접속시 delete.html를 보내주자
app.get('/delete', (req, res)=>{
  res.sendFile(__dirname + '/delete.html');
});
// '/update'로 접속시 update.html를 보내주자
app.get('/update', (req, res)=>{
  res.sendFile(__dirname + '/update.html');
});

// app으로부터 넘어오는 POST 자료를 받아서 DB의 컬렉션에 기록하자
app.post('/add', (req, res)=>{
  let appTitle = req.body.title;
  let appOrder = req.body.order;
  

  // 자료 갯수
  // findOne(조건, 콜백);
  todoAppDB.collection('postcount').findOne({개시물갯수:'개시물갯수'}, (err, result)=>{
    if(err) return console.log('개시물갯수 검색 실패');
    let totalCount = result.전체갯수;
    //todoApp 자료 저장
    todoAppDB.collection('todoApp').insertOne({title:appTitle, order:Number(appOrder), _id:totalCount+1},(err, result)=>{
      if(err) return console.log('/add 오류');
      console.log('/add 성공');
      // updateOne(조건{}, 변경값{}, 콜백);
      // {$inc:{전체갯수:1}} -> 전체갯수의 값을 1로 만드는게 아니라 1씩 증가시키는 뜻.
      todoAppDB.collection('postcount').updateOne({개시물갯수:'개시물갯수'},{$inc:{전체갯수:1}},(err, result)=>{
        if(err) return console.log('문서갯수 변경 실패');
      });
    });
  });

  
  res.redirect('/write');
});

// ejs로 접근하는 앱에게 list.ejs를 제공하자
app.get('/', (req, res)=>{
  todoAppDB.collection('todoApp').find().toArray((err, result)=>{
    if(err) return console.log('자료검색 오류');
    res.render('index.ejs', {todoData:result});
  });
  
  // 반드시 views폴더에 ejs 파일이 위치해야함.
});