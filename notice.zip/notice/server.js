const express = require('express');
const app = express();

// 8080포트로 서버 open
app.listen(8080, function(){
  // 접속후 실행될 구역
  console.log('8080포트로 접속됨');
});

app.get('/pet', function(req, res){ 
  res.send('펫 페이지입니다.');
});

app.get('/beauty', function(req, res){ 
  res.send('뷰티 페이지입니다.');
});

app.get('/', (req, res)=>{ 
  res.sendFile(__dirname + '/index.html');
});