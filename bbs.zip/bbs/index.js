const express = require('express');
const app = express();

app.listen(3000, ()=>{
  console.log('3000번 포트 오픈');
});

app.get('/read', (req, res)=>{
  res.send('요청의 응답 결과입니다.')
});