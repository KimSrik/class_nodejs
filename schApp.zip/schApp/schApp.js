const express = require('express');
const { sendFile } = require('express/lib/response');
const app = express();

const MongoClient = require('mongodb').MongoClient;

app.use(express.json());
app.use(express.urlencoded({extended:true}));

let scheduleDB;

MongoClient.connect('mongodb+srv://admin:qwer1234@cluster0.mikzh.mongodb.net/schedule?retryWrites=true&w=majority', (err, client)=>{
  if(err) return console.log(err);

  scheduleDB = client.db('schedule');

  app.listen(8080, ()=>{
    console.log('8080번 포트 오픈');
  })
});

app.get('/', (req, res)=>{
  res.sendFile(__dirname + '/index.html');
});

app.get('/index.html', (req, res)=>{
  res.sendFile(__dirname + '/index.html');
});

app.get('/write', (req, res)=>{
  res.sendFile(__dirname + '/write.html');
});

app.post('/add', (req, res)=>{
  scheduleDB.collection('today').insertOne({
    title: req.body.title,
    date: req.body.date,
    _id: 100
    }, (err, result)=>{
    if(err) return console.log('저장 실패');
    console.log(req.body.title + ' 는 저장에 성공하였습니다.');
  })
  res.sendFile(__dirname + '/index.html');
});