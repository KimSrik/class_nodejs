const express = require('express');
const app = express();

app.use(express.urlencoded({extended: true}));
app.use(express.json());

app.set('view engine', 'ejs');

const MongoClient = require('mongodb').MongoClient;

let bookLibDB;
let DBURL = 'mongodb+srv://admin:qwer1234@cluster0.mikzh.mongodb.net/bookLibDB?retryWrites=true&w=majority';

MongoClient.connect(DBURL, (err, result)=>{
  if(err) return console.log("Database connect Fail!");

  bookLibDB = result.db('bookLibDB');

  app.listen(8080, ()=>{
    console.log('port : 8080 open & Database connect Success!');
  });
});

app.get('/', (req, res)=>{
  res.render('index.ejs', {});
});

app.get('/bookList', (req, res)=>{
  bookLibDB.collection('bookLib').find().toArray((err, result)=>{
    if(err) return console.log('book search fail !!!');
    res.render('bookList.ejs', {bookData:result});
  });
  
});