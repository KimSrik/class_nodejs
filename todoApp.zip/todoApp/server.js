const express = require('express');
const app = express();
app.use(express.urlencoded({extended:true}));

app.set('view engine', 'ejs');

const MongoClient = require('mongodb').MongoClient;


let todoAppDB;
let DBAddress = 'mongodb+srv://admin:qwer1234@cluster0.mikzh.mongodb.net/todoAppDB?retryWrites=true&w=majority';
MongoClient.connect(DBAddress, (err, result)=>{
  if(err) return console.log('데이터베이스 접근 실패');
  
  todoAppDB = result.db('todoAppDB');
  // todoAppDB.collection('todoApp')


  app.listen(8080, ()=>{
    console.log('8080포트 접속 완료, DB 접속 성공');
  });
});

app.get('/', (req, res)=>{
  todoAppDB.collection('todoApp').find().toArray((err, result)=>{
    if(err) return console.log('자료 가져오기 오류');
    res.render('index.ejs', {todoApp:result});
  });
});

app.get('/write', (req, res)=>{
  res.render('write.ejs');
});

app.post('/add', (req, res)=>{
  todoAppDB.collection('todoApp').insertOne({title:req.body.title, order:req.body.order}, (err,result)=>{
    if(err) return console.log('저장오류');
    console.log(`저장이 완료되었습니다.`);
    res.redirect('/');
  });
});