// 익스프레스로 서버개체 생성
const express = require('express');
const app = express();

// mongoDB 생성
const MongoClient = require('mongodb').MongoClient;

// post로 자료 전송을 위한 body-parser middleware
app.use(express.json());
app.use(express.urlencoded({extended:true}));

let activeDB;

// DB 접속
// MongoClient.connect(경로, 콜백);
// 경로 : // mongodb+srv://<아이디>:<password>@cluster0.mikzh.mongodb.net/<데이터베이스이름>?retryWrites=true&w=majority
// 콜백 : 콜백(에러, db접속)=>{}
MongoClient.connect('mongodb+srv://admin:qwer1234@cluster0.mikzh.mongodb.net/list?retryWrites=true&w=majority', (err, client)=>{
  if(err) return console.log(err);

  activeDB = client.db('list');
  // activeDB.collection('list').insertOne({title:'집가기', date:'2022-04-18'}, (err, result)=>{
  //   if(err) return console.log('저장 실패');
  //   console.log('저장완료');
  // });

  // 서버 오픈
  app.listen(8080, ()=>{
    console.log('8080번 포트 오픈');
  });
});

// app.get('/', (req, res)=>{
//   res.sendFile(__dirname + '/index.html');
// });

// 누군가가 '/write'로 접속하면 'write.html'을 응답하라.
app.get('/write', (req, res)=>{
  res.sendFile(__dirname + '/write.html');
});

// 누군가가 '/add'로 접속하면 입력폼의 자료 2개(title, date)를 서버로 가져와라.
app.post('/add', (req, res)=>{
  console.log(req.body.title);
  activeDB.collection('list').insertOne(req.body,(err, result)=>{
    if(err) return console.log('저장 실패');
    console.log('저장완료');
  });
});

// app.post('/add', (req, res)=>{
//     console.log(req.body);
//     res.send('전송성공');
//   });





// 홈페이지 로드
// app.get(경로, (요청,응답)=>{

// });

// app.get('/', (req, res)=>{
//   res.sendFile(__dirname + '/index.html');
// });

// // 기록페이지 로드
// app.get('/write', (req, res)=>{
//   res.sendFile(__dirname + '/write.html');
// });

// // write로 부터 post된 정보
// app.post('/add', (req, res)=>{
//   console.log(req.body);
//   res.send('전송성공');
// });


